<h3>some text</h3><ad:a2 href="bar foo
si"><a href='bar' goo foo=ooo oo=ooo kk
kk></a><h1 foo="foo<?= $a // foo ?>c
com">h1 text</h1>
<!-- foo <?php function foo() { $bar = 077; /* ?>*///?> http://foo.com
<h1> --><?php } $g = $a xor $c;
$b = "\" \``"; $c = `\" \`" {$a[$a 
->	
	doo * 0x2] } bar`;
$a = ( 	bool)(INT	 )(binary)<<<FOO
Foo 1 \n \x0 \0 \007 \" \` \xFF \j \\\"\$ \{
$foo[$bar][there]
{${$name}}
{\$\${{$foo->bar[1]}
{$foo[b<<< 	'BAR'
bar$b
UBAR;
UBAR
BAR
]->ff["Bar"["0"[0]] . <<<EO
$foo[kk][ll]
EO
/*comment*/]}
GFOO;
FOO;

/**@foo @foo {@foo bar} {@link http://foobar.com/}
 *@throws FooException
 * @uses 	$used
 * @return	Foo|Bar[]|	mixed|Baz[]|	Bat | Bak 
 * @param (mixed|int[]|Foo)[]|Foo[]	$param fo
 * @param $foo_hh Foo bar
comentario */
//comentario
#come

$gata{"1"} = b'gata\''; echo b"gata";
echo "A Mini é $gata!
Isto \$bar $foo[bar] ainda é {$_SERVER["{$_SERVER["$_SERVER[foo]"]}"]} string
$foo->bar->sing $foo[$bar][there] $foo[0b001] ${a[/*foo*/4]}";
