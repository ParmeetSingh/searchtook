int foobar(int a) {
   return a * a;
}
